//
//  XLPageSegmentedTitleView.h
//  XLPageViewControllerExample
//
//  Created by MengXianLiang on 2019/5/9.
//  Copyright © 2019 xianliang meng. All rights reserved.
//  https://github.com/mengxianliang/XLPageViewController
//  Segmented样式标题栏

#import "XLPageBasicTitleView.h"

NS_ASSUME_NONNULL_BEGIN

@interface XLPageSegmentedTitleView : XLPageBasicTitleView

@end

NS_ASSUME_NONNULL_END
