//
//  Reader17kSDK.h
//  Reader17kSDK
//
//  Created by Ink on 2021/1/4.
//

#import <Foundation/Foundation.h>

//! Project version number for Reader17kSDK.
FOUNDATION_EXPORT double Reader17kSDKVersionNumber;

//! Project version string for Reader17kSDK.
FOUNDATION_EXPORT const unsigned char Reader17kSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Reader17kSDK/PublicHeader.h>

#import <Reader17kSDK/XLPageSegmentedTitleView.h>
#import <Reader17kSDK/XLPageViewController.h>
#import <Reader17kSDK/XLPageViewControllerConfig.h>
#import <Reader17kSDK/XLPageViewControllerUtil.h>
#import <Reader17kSDK/XLPageBasicTitleView.h>
#import <Reader17kSDK/XLPageTitleCell.h>
